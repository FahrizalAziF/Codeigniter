<?php

use PhpParser\Node\Expr\FuncCall;

defined('BASEPATH') or exit('No direct script access allowed');


class Pasar extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_produk');
    }

    public function toko_pasar($id_pasar = null)
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar');
        $this->db->select('COUNT(id_toko)as jml,nama_pasar');
        $this->db->join('tbl_toko', 'tbl_toko.id_pasar=tbl_pasar.id_pasar');
        $this->db->where('tbl_pasar.id_pasar', $id_pasar);
        $data['pasar'] = $this->db->get('tbl_pasar')->row();

        $this->db->where('status', 'Telah Dikonfirmasi');
        $this->db->where('id_pasar', $id_pasar);
        $data['toko'] = $this->db->get('tbl_toko')->result();

        $this->load->view('pembeli/v_pasar', $data);
        $this->load->view('template/footer');
    }

    public function produk_toko($id_toko = null)
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar');

        $this->db->select('COUNT(id_produk)as jml,nama_toko');
        $this->db->join('tbl_produk', 'tbl_produk.id_toko=tbl_toko.id_toko');
        $this->db->where('tbl_toko.id_toko', $id_toko);
        $data['toko'] = $this->db->get('tbl_toko')->row();

        $this->db->join('tbl_produk', 'tbl_produk.id_toko=tbl_toko.id_toko');
        $this->db->where('tbl_toko.id_toko', $id_toko);
        $data['produk'] = $this->db->get('tbl_toko')->result();

        $this->load->view('pembeli/v_toko', $data);
        $this->load->view('template/footer');
    }


    public function harga_pasar()
    {
        $id_pasar = $this->session->userdata('id_pasar');
        $this->load->view('template/header');
        $this->load->view('template/navbar');

        $this->db->where('id_pasar', $id_pasar);
        $data['bahan'] = $this->db->get('tbl_bahan')->result();

        $this->db->where('id_pasar', $id_pasar);
        $data['pokok'] = $this->db->get('tbl_bahan_pokok')->result();
        $this->load->view('admin/v_harga_pasar', $data);
        $this->load->view('template/footer');
    }

    public function harga_perpasar()
    {
        $id_pasar = $this->session->userdata('id_pasar');
        $this->load->view('template/header');
        $this->load->view('template/navbar');

        $this->db->where('id_pasar', $id_pasar);
        $data['bahan'] = $this->db->get('tbl_bahan')->result();

        $data['pasar'] = $this->db->get('tbl_pasar')->result();

        $this->db->where('id_pasar', $id_pasar);
        $data['pokok'] = $this->db->get('tbl_bahan_pokok')->result();
        $this->load->view('pembeli/v_harga_pasar', $data);
        $this->load->view('template/footer');
    }

    public function addHarga()
    {
        $id_pasar = $this->session->userdata('id_pasar');
        $post = $this->input->post();
        $this->db->where('id_bahan', $post['id_bahan']);
        $cek = $this->db->get('tbl_bahan')->row();
        //-----------------------------------------------

        $this->id_bahan = $post['id_bahan'];
        $this->harga_bahan = $post['harga_bahan'];
        $this->id_satuan = $cek->id_satuan;
        $this->id_kategori = $cek->id_kategori;
        $this->id_pasar = $id_pasar;
        $this->tgl_input = date("Y-m-d");

        $qry = $this->db->insert('tbl_bahan_pokok', $this);
        if ($qry) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" >
                    <p> Data berhasil ditambahkan</p>
                </div>'
            );
            redirect('Pasar/harga_pasar');
        }
    }

    public function hargaList()
    {
        $date = $_GET['date'];
        $id_pasar = $this->session->userdata('id_pasar');
        $tgl = date('Y-m-d', strtotime('-1 days', strtotime($date)));
        $kategori = $this->db->get('tbl_kategori')->result();
        //------------------------------------------------------------------------
        $i = 1;
        foreach ($kategori as $k) { ?>
            <tr>
                <th scope="row"><?= $i++ ?></th>
                <td colspan="7"><?= $k->nama_kategori ?></td>
                <?php
                //-----------------------------------------------------------------------------

                $this->db->join('tbl_satuan', 'tbl_satuan.id_satuan=tbl_bahan_pokok.id_satuan');
                $this->db->join('tbl_bahan', 'tbl_bahan.id_bahan=tbl_bahan_pokok.id_bahan');
                $this->db->where('tbl_bahan_pokok.id_kategori', $k->id_kategori);
                $this->db->where('tbl_bahan_pokok.id_pasar', $id_pasar);
                $this->db->where('tgl_input', $date);
                $bahan = $this->db->get('tbl_bahan_pokok')->result();
                foreach ($bahan as $b) {
                    $this->db->where('id_kategori', $k->id_kategori);
                    $this->db->where('id_pasar', $id_pasar);
                    $this->db->where('tgl_input', $tgl);
                    $this->db->where('id_bahan', $b->id_bahan);
                    $prev = $this->db->get('tbl_bahan_pokok')->row_array();
                ?>
            <tr>
                <td></td>
                <td>-<?= $b->nama_bahan ?></td>
                <td><?= $b->nama_satuan ?></td>
                <td>Rp. <?= number_format($prev['harga_bahan'], 0, ',', '.') ?></td>
                <td>Rp. <?= number_format($b->harga_bahan, 0, ',', '.') ?></td>
                <td>Rp. <?= number_format($b->harga_bahan - $prev['harga_bahan'], 0, ',', '.') ?></td>
                <td><?php
                    $jml = ($b->harga_bahan - $prev['harga_bahan']);
                    $q = ($jml / $prev['harga_bahan']) * 100;
                    echo $q;
                    ?>%</td>
                <!-- <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalEdit<?= $b->id_bahan_pokok ?>"><i class="fa fa-pencil"></i> </button> -->
                <td> <a href="<?= base_url('Pasar/deletePokok/' . $b->id_bahan_pokok) ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> </a>
                </td>
            </tr>
        <?php } ?>
        </tr>
    <?php } ?>
    <?php }

    public function hargaPasar()
    {
        $date = $_GET['date'];
        $pasar = $_GET['pasar'];
        // $id_pasar = $this->session->userdata('id_pasar');
        $tgl = date('Y-m-d', strtotime('-1 days', strtotime($date)));
        $kategori = $this->db->get('tbl_kategori')->result();
        //------------------------------------------------------------------------
        $i = 1;
        foreach ($kategori as $k) { ?>
        <tr>
            <th scope="row"><?= $i++ ?></th>
            <td colspan="7"><?= $k->nama_kategori ?></td>
            <?php
            //-----------------------------------------------------------------------------

            $this->db->join('tbl_satuan', 'tbl_satuan.id_satuan=tbl_bahan_pokok.id_satuan');
            $this->db->join('tbl_bahan', 'tbl_bahan.id_bahan=tbl_bahan_pokok.id_bahan');
            $this->db->where('tbl_bahan_pokok.id_kategori', $k->id_kategori);
            $this->db->where('tbl_bahan_pokok.id_pasar', $pasar);
            $this->db->where('tgl_input', $date);
            $bahan = $this->db->get('tbl_bahan_pokok')->result();
            foreach ($bahan as $b) {
                $this->db->where('id_kategori', $k->id_kategori);
                $this->db->where('id_pasar', $pasar);
                $this->db->where('tgl_input', $tgl);
                $this->db->where('id_bahan', $b->id_bahan);
                $prev = $this->db->get('tbl_bahan_pokok')->row_array();
            ?>
        <tr>
            <td></td>
            <td>-<?= $b->nama_bahan ?></td>
            <td><?= $b->nama_satuan ?></td>
            <td>Rp. <?= number_format($prev['harga_bahan'], 0, ',', '.') ?></td>
            <td>Rp. <?= number_format($b->harga_bahan, 0, ',', '.') ?></td>
            <td>Rp. <?= number_format($b->harga_bahan - $prev['harga_bahan'], 0, ',', '.') ?></td>
            <td><?php
                $jml = ($b->harga_bahan - $prev['harga_bahan']);
                if ($prev['harga_bahan'] > 0) {
                    $q = ($jml / $prev['harga_bahan']) * 100;
                    echo $q;
                } else {
                    echo "100";
                }

                ?>%</td>
            <!-- <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalEdit<?= $b->id_bahan_pokok ?>"><i class="fa fa-pencil"></i> </button> -->
        </tr>
    <?php } ?>
    </tr>
<?php } ?>
<?php }

    public function bahan()
    {

        $this->load->view('template/header');
        $this->load->view('template/navbar');

        $data['kategori'] = $this->db->get('tbl_kategori')->result();
        $data['satuan'] = $this->db->get('tbl_satuan')->result();

        $this->load->view('admin/v_bahan', $data);
        $this->load->view('template/footer');
    }

    public function addBahan()
    {
        $post = $this->input->post();
        $id_pasar = $this->session->userdata('id_pasar');
        $this->nama_bahan = $post['nama_bahan'];
        $this->id_kategori = $post['id_kategori'];
        $this->id_satuan = $post['id_satuan'];
        $this->id_pasar = $id_pasar;
        $qry = $this->db->insert('tbl_bahan', $this);
        if ($qry) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" >
                    <p> Bahan berhasil ditambahkan</p>
                </div>'
            );
            redirect('Pasar/bahan');
        }
    }
    public function deletePokok($id = null)
    {
        $this->db->where('id_bahan_pokok', $id);
        $qry = $this->db->delete('tbl_bahan_pokok');
        if ($qry) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger col-md-12" >
                    <p> Data berhasil dihapus</p>
                </div>'
            );
            redirect('Pasar/harga_pasar');
        }
    }

    public function grafik_harga()
    {

        $postData = $this->input->post();
        $this->load->view('template/header');
        $this->load->view('template/navbar');
        $this->db->select('SUM(harga_bahan) as jmlh,nama_bahan');
        $this->db->join('tbl_bahan', 'tbl_bahan.id_bahan=tbl_bahan_pokok.id_bahan');
        $this->db->group_by('tbl_bahan_pokok.id_bahan');
        $this->db->where('tgl_input', '2020-11-15');
        $data['qry'] = $this->db->get('tbl_bahan_pokok')->result();

        $data['pasar'] = $this->db->get('tbl_pasar')->result();
        $data['kategori'] = $this->db->get('tbl_kategori')->result();
        $this->load->view('pembeli/v_grafik_harga', $data);
        $this->load->view('template/footer');
    }

    public function grafikHarga()
    {
        $date = $_GET['date'];
        $pasar = $_GET['pasar'];
        $kategori = $_GET['kategori'];
        $this->db->select('SUM(harga_bahan) as jmlh,nama_bahan');
        $this->db->join('tbl_bahan', 'tbl_bahan.id_bahan=tbl_bahan_pokok.id_bahan');
        $this->db->group_by('tbl_bahan_pokok.id_bahan');
        $this->db->where('tbl_bahan_pokok.tgl_input', $date);
        $this->db->where('tbl_bahan_pokok.id_pasar', $pasar);
        $this->db->where('tbl_bahan_pokok.id_kategori', $kategori);
        $qry = $this->db->get('tbl_bahan_pokok')->result();
    }

    public function display_harga()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar');
        $data['qry'] = $this->db->get('tbl_bahan_pokok')->result();
        $data['pasar'] = $this->db->get('tbl_pasar')->result();
        $this->load->view('pembeli/v_display_harga', $data);
        $this->load->view('template/footer');
    }

    public function displayHarga()
    {
        $date = $_GET['date'];
        $pasar = $_GET['pasar'];


        $this->db->join('tbl_bahan', 'tbl_bahan.id_bahan=tbl_bahan_pokok.id_bahan');
        $this->db->join('tbl_satuan', 'tbl_satuan.id_satuan=tbl_bahan_pokok.id_satuan');
        $this->db->where('tbl_bahan_pokok.id_pasar', $pasar);
        $this->db->where('tgl_input', $date);
        $qry = $this->db->get('tbl_bahan_pokok')->result();
        if ($qry) {
            foreach ($qry as $q) { ?>
        <div class="card m-1" style="background-color: #00a8ff; width:24%; ">
            <div class="card-body">
                <p style="color: white; font-size:20px;"><?= $q->nama_bahan ?>/<?= $q->nama_satuan ?></p>
                <h2 style="color: white;">Rp. <?= number_format($q->harga_bahan, 0, ',', '.') ?></h2>
            </div>
        </div>

    <?php }
        } else { ?>

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin_bottom_30_all">
        <img src="<?= base_url() ?>assets/img/shop.png" style="width: 100px;height:100px;display: block; margin: auto;">
        <h4 class="mt-3" style="text-align: center;">Data Tidak Tersedia</h4>
    </div>

<?php }
    }
}
