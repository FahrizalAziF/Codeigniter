<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Toko extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('M_produk');
    }

    public function index()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar');
        $id_akun = $this->session->userdata('id_akun');
        $this->db->where('id_akun', $id_akun);
        $data['pasar'] = $this->db->get('tbl_pasar')->row();
        if ($data['pasar']->id_pasar) {
            $data['kategori'] = $this->db->get('tbl_kategori')->result();

            $this->db->join('tbl_akun', 'tbl_akun.id_akun=tbl_toko.id_akun');
            $this->db->where('id_pasar', $data['pasar']->id_pasar);
            $data['toko'] = $this->db->get('tbl_toko')->result();
            $this->load->view('admin/v_list_toko', $data);
        } else {
            redirect('Login');
        }
        $this->load->view('template/footer');
    }

    public function produkList()
    {
        // POST data
        $postData = $this->input->post();
        // Get data
        $data = $this->M_produk->getProduk($postData);

        echo json_encode($data);
    }

    public function konfirmasi()
    {
        $post = $this->input->post();
        $id_toko = $post['id_toko'];
        $status = "Telah Dikonfirmasi";
        $this->db->set('status', $status);
        $this->db->where('id_toko', $id_toko);
        $data = $this->db->update('tbl_toko', $this);
        if ($data) {
            echo "<script>
            alert('Ingatkan admin toko dengan wa');
            window.open('https://api.whatsapp.com/send?phone=" . $post['no_wa'] . "&text=Akun anda adalah Username (" . $post['username'] . ") dan Password (" . $post['password'] . ") telah di konfirmasi oleh pihak admin','_blank' );
            window.location.href = '" . base_url('Toko') . "';
        </script>";
            base_url('Toko/');
        }
    }


    public function addToko()
    {
        $post = $this->input->post();

        $data = array(
            'username' => $post['username'],
            'password' => $post['password'],
            'id_user' => '3'
        );
        $akun = $this->db->insert('tbl_akun', $data);

        if ($akun) {
            $this->db->order_by('id_akun', 'DESC');
            $akun = $this->db->get('tbl_akun')->row_array();

            $this->id_pasar = $post['id_pasar'];
            $this->nama_toko = $post['nama_toko'];
            $this->nama_pemilik_toko = $post['nama_pemilik_toko'];
            $this->no_hp_toko = $post['no_hp_toko'];
            $this->foto_toko =  $this->uploadFoto();
            $this->id_akun = $akun['id_akun'];
            $this->status = "Belum Dikonfirmasi";
            $add = $this->db->insert('tbl_toko', $this);
            if ($add) {
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-info" >
                        <p> Berhasil membuat akun, akun akan aktif setelah dikonfirmasi</p>
                    </div>'
                );
                redirect('Admin/daftarAdminToko');
            }
        }
    }
    public function deleteToko($id_toko = null)
    {
        $this->db->where('id_toko', $id_toko);
        $cek = $this->db->get('tbl_toko')->row();
        //----------------------------------------------
        $this->db->where('id_akun', $cek->id_akun);
        $this->db->delete('tbl_akun');
        //----------------------------------------------
        $this->db->where('id_toko', $id_toko);
        $cekProduk = $this->db->get('tbl_produk')->result();
        foreach ($cekProduk as $c) {
            //-----------------------------------------
            $this->db->where('id_produk', $c->id_produk);
            $cekTrans = $this->db->get('tbl_keranjang')->result();
            foreach ($cekTrans as $ck) {
                $this->db->where('id_transaksi', $ck->id_trans);
                $this->db->delete('tbl_transaksi');
            }
            //-----------------------------------------
            $this->db->where('id_produk', $c->id_produk);
            $this->db->delete('tbl_keranjang');
        }
        $this->db->where('id_toko', $id_toko);
        $this->db->delete('tbl_produk');
        //----------------------------------------------
        $this->db->where('id_toko', $id_toko);
        $delete = $this->db->delete('tbl_toko');
        if ($delete) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" >
                    <p> Toko berhasil dihapus</p>
                </div>'
            );
            redirect('Toko');
        }
    }

    private function uploadFoto()
    {


        $config['upload_path']          =  'upload';
        $config['allowed_types']        = 'gif|jpg|jpeg|png|JPG';
        $config['max_size']             = 9048;
        $config['overwrite']            = true;
        $config['file_name']            = md5(date('l, d-M-Y / H:i:s a'));

        // 1MB
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $this->upload->initialize($config);
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('foto_toko')) {
            return $this->upload->data("file_name");
        }

        return "store.png";
    }

    public function admin_toko()
    {
        $this->load->view('template/header');
        $this->load->view('template/navbar');
        $id_toko = $this->session->userdata('id_toko');


        $data['satuan'] = $this->db->get('tbl_satuan')->result();
        $this->db->join('tbl_pasar', 'tbl_pasar.id_pasar=tbl_toko.id_pasar');
        $this->db->where('id_toko', $id_toko);
        $data['toko'] = $this->db->get('tbl_toko')->row_array();
        if ($data['toko']) {
            $this->db->where('id_toko', $id_toko);
            $data['produk'] = $this->db->get('tbl_produk')->result();

            $data['kategori'] = $this->db->get('tbl_kategori')->result();
            $this->load->view('admin/v_list_toko_produk', $data);
        } else {
            redirect('Login');
        }


        $this->load->view('template/footer');
    }

    public function addProduk()
    {
        $id_toko = $this->session->userdata('id_toko');
        $post = $this->input->post();
        $this->nama_produk = $post['nama_produk'];
        $this->harga_produk = $post['harga_produk'];
        $this->stok_produk = $post['stok_produk'];
        $this->id_kategori = $post['id_kategori'];
        $this->id_satuan = $post['id_satuan'];
        $this->foto_produk = $this->uploadFotoProduk();
        $this->id_toko = $id_toko;
        $add = $this->db->insert('tbl_produk', $this);
        if ($add) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-info alert-dismissible fade show" role="alert">
                    <p> Produk berhasil ditambahkan</p>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>'
            );
            redirect('Toko/admin_toko');
        }
    }

    public function editProduk()
    {
        $post = $this->input->post();
        $data = array(
            'nama_produk' => $post['nama_produk'],
            'id_kategori' => $post['id_kategori'],
            'id_toko' => $post['id_toko'],
            'harga_produk' => $post['harga_produk'],
            'stok_produk' => $post['stok_produk'],
            'foto_produk' => $this->uploadFotoProduk()
        );

        $this->db->where('id_produk', $post['id_produk']);
        $edit = $this->db->update('tbl_produk', $data);

        if ($edit) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-info alert-dismissible fade show" role="alert">
                    <p> Produk berhasil ditambahkan</p>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>'
            );
            redirect('Toko/admin_toko');
        }
    }
    public function hapusProduk($id_produk = null)
    {
        $this->db->where('id_produk', $id_produk);
        $cekTrans = $this->db->get('tbl_keranjang')->result();
        foreach ($cekTrans as $ck) {
            $this->db->where('id_transaksi', $ck->id_trans);
            $this->db->delete('tbl_transaksi');
        }
        //-----------------------------------------
        $this->db->where('id_produk', $id_produk);
        $this->db->delete('tbl_keranjang');

        $this->db->where('id_produk', $id_produk);
        $qry = $this->db->delete('tbl_produk');
        if ($qry) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" >
                    <p> Produk berhasil dihapus</p>
                </div>'
            );
            redirect('Toko/admin_toko');
        }
    }

    private function uploadFotoProduk()
    {


        $config['upload_path']          =  'upload';
        $config['allowed_types']        = 'gif|jpg|jpeg|png|JPG';
        $config['max_size']             = 9048;
        $config['overwrite']            = true;
        $config['file_name']            = md5(date('l, d-M-Y / H:i:s a'));
        $this->upload->initialize($config);
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('foto_produk')) {
            return $this->upload->data("file_name");
        }

        return "store.png";
    }
}
