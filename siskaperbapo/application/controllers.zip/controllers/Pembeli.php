<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pembeli extends CI_Controller
{

    function __construct()
    {

        parent::__construct();
        $this->load->helper('url');
    }

    public function index()
    {

        $this->load->view('template/header');
        $this->load->view('v_login');
        $this->load->view('template/footer');
    }

    public function daftar()
    {

        $this->load->view('template/header');
        $this->load->view('v_daftar');
        $this->load->view('template/footer');
    }

    public function addPembeli()
    {

        $post = $this->input->post();
        $username = $post['username'];
        $this->db->where('username', $username);
        $cek = $this->db->get('tbl_akun')->row_array();
        if (!$cek) {
            $data = array(
                'username' => $username,
                'password' => $post['password'],
                'id_user' => "4",
            );
            $row = $this->db->insert('tbl_akun', $data);
            if ($row) {
                $this->db->order_by('id_akun', 'DESC');
                $cek = $this->db->get('tbl_akun')->row_array();
                $data = array(
                    'nama_lengkap' => $post['nama_lengkap'],
                    'no_hp' => $post['no_hp'],
                    'alamat' => $post['alamat'],
                    'id_akun' => $cek['id_akun']
                );
                $this->db->insert('tbl_profile', $data);
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-success" >
                        <p> Pendaftaran Berhasil</p>
                    </div>'
                );
                redirect('Login');
            }
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger" >
                    <p> Username telah digunakan' . $post['username'] . '</p>
                </div>'
            );
            redirect('Pembeli/daftar');
        }
    }
}
