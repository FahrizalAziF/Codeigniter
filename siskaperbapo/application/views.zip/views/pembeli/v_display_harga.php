<!-- jQuery Library -->

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-info row">
                <div class="col-md-3">
                    <label>Tanggal : </label>
                    <input class="form-control mr-2" type="date" id="sel_date" value="<?php echo date("Y-m-d"); ?>">
                </div>
                <div class="col-md-3">
                    <label>Pasar :</label>
                    <select name="id_pasar" id="sel_pasar" class="form-control ">

                        <?php
                        foreach ($pasar as $p) {
                        ?>
                            <option value="<?= $p->id_pasar ?>">
                                <?= $p->nama_pasar ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row  col-md-12 mb-2">

        </div>
        <?php echo $this->session->flashdata('message'); ?>
        <div class="card text-center " style="width: 100%;">
            <div class="card-header">
                Harga Produk
            </div>

            <div class="card-body ">

                <div id="display" class="row">

                </div>
            
            </div>

            <div class="card-footer text-muted">
                2 days ago
            </div>

        </div>
    </div>
</div>
</div>

<script>
    $(document).ready(function() {
        displayharga();
        $("#sel_date").change(function() {
            // let a = $(this).val();
            // console.log(a);
            displayharga();
        });
        $("#sel_pasar").change(function() {
            // let a = $(this).val();
            // console.log(a);
            displayharga();
        });
    });

    function displayharga() {
        var date = $("#sel_date").val();
        var pasar = $("#sel_pasar").val();
        $.ajax({
            url: "<?= base_url('Pasar/displayHarga') ?>",
            data: {
                date: date,
                pasar: pasar
            },
            success: function(data) {
                // $("#datapokok tbody").html('<tr><td colspan="8" align="center">Tidak Ada Data</td></tr>')
                $("#display").html(data)
            }
        })
    }
</script>