<div class="container">

    <form method="post" action="<?= base_url() ?>Pembeli/addPembeli">
        <div style="transform: translate(-50%, -50%);left: 50%;top: 50%;position: absolute;">

            <?php echo $this->session->flashdata('message'); ?>
            <div class="card">
                <div class="card-header">
                    Buat Akun
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Nama Lengkap</label>
                            <input class="form-control" name="nama_lengkap" placeholder="Nama Lengkap" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>No Hp</label>
                            <input class="form-control" name="no_hp" placeholder="No HP" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input style="height: 75px;" class="form-control" name="alamat" placeholder="Alamat" required>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Username</label>
                            <input class="form-control" name="username" placeholder="Username" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Password</label>
                            <input class="form-control" name="password" type="password" placeholder="Password" required>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-success" type="submit" style="float: right;">Daftar</button>
                </div>
            </div>
        </div>
    </form>
</div>