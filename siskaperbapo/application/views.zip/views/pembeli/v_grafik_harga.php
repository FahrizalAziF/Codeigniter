<!-- jQuery Library -->

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-info row">
                <div class="col-md-3">
                    <label>Tanggal : </label>
                    <input class="form-control mr-2" type="date" id="sel_date" value="<?php echo date("Y-m-d"); ?>">
                </div>
                <div class="col-md-3">
                    <label>Pasar :</label>
                    <select name="id_pasar" id="sel_pasar" class="form-control ">

                        <?php
                        foreach ($pasar as $p) {
                        ?>
                            <option value="<?= $p->id_pasar ?>">
                                <?= $p->nama_pasar ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label>Komoditas :</label>
                    <select name="id_kategori" id="sel_kategori" class="form-control ">

                        <?php
                        foreach ($kategori as $p) {
                        ?>
                            <option value="<?= $p->id_kategori ?>">
                                <?= $p->nama_kategori  ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row  col-md-12 mb-2">

        </div>
        <?php echo $this->session->flashdata('message'); ?>
        <div class="card text-center " style="width: 100%;">
            <div class="card-header">
                Grafik
            </div>

            <div class="card-body">
                <div id="container"></div>
            </div>
            <div class="card-footer text-muted">
                2 days ago
            </div>
        </div>
    </div>
</div>
</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<script type="text/javascript">
    // globally available
    $(document).ready(function() {
        grafik();

    });

    function grafik() {
        var chart1;
        chart1 = new Highcharts.Chart({
            chart: {
                renderTo: 'container',
                type: 'column'
            },
            title: {
                text: 'Grafik Harga Per Hari '
            },
            xAxis: {
                categories: ['Komoditas']
            },
            yAxis: {
                title: {
                    text: 'Harga Bahan'
                }
            },
            series: [
                <?php
                foreach ($qry as $q) {
                ?> {
                        name: '<?= $q->nama_bahan ?>',
                        data: [<?= $q->jmlh; ?>]
                    },
                <?php } ?>

            ]
        });
    }
</script>