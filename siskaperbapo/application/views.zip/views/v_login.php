<div class="container">

    <form method="post" action="<?= base_url() ?>Login/cekLogin">
        <div style="transform: translate(-50%, -50%);left: 50%;top: 50%;position: absolute;">

            <?php echo $this->session->flashdata('message'); ?>
            <div class="card">
                <div class="card-header">
                    Login
                </div>
                <div class="card-body">

                    <div class="form-group">
                        <label>Username</label>
                        <input class="form-control" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input class="form-control" name="password" type="password" placeholder="Password" required>
                    </div>

                </div>
                <div class="card-footer">
                    <button class="btn btn-success" type="submit" style="float: right;">Login</button>
                </div>
            </div>
        </div>
    </form>
</div>