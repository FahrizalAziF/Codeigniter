<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <div class="alert alert-info">
                <p> Daftar Bahan</p>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 10%;">No</th>
                        <th scope="col">Nama Bahan</th>
                        <th scope="col">Satuan</th>
                        <th scope="col" style="text-align: center;">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $id_pasar = $this->session->userdata('id_pasar');
                    $i = 1;
                    foreach ($kategori as $p) {
                    ?>
                        <tr>
                            <th scope="row"><?= $i++ ?></th>
                            <td colspan="3"><?= $p->nama_kategori ?></td>

                            <?php
                            $this->db->join('tbl_satuan', 'tbl_satuan.id_satuan=tbl_bahan.id_satuan');
                            $this->db->where('id_kategori', $p->id_kategori);
                            $this->db->where('id_pasar', $id_pasar);
                            $data = $this->db->get('tbl_bahan')->result();
                            foreach ($data as $d) {
                            ?>
                        <tr>
                            <td></td>
                            <td> -<?= $d->nama_bahan ?></td>
                            <td><?= $d->nama_satuan ?></td>
                            <td style="text-align: center;"> <button class="btn btn-success mb-1 btn-sm" data-toggle="modal" data-target="#modalEdit<?= $d->id_bahan ?>"><i class="fa fa-pencil"></i> </button>
                                <button class="btn btn-danger mb-1 btn-sm"><i class="fas fa-trash"></i> </button></td>
                        </tr>
                    <?php } ?>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <?php echo $this->session->flashdata('message'); ?>
            <form method="post" action="<?= base_url() ?>Pasar/addBahan">
                <div class="card">

                    <div class="card-header">
                        Tambah Bahan
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Nama Bahan</label>
                            <input class="form-control" name="nama_bahan" placeholder="Nama Bahan" required>
                        </div>
                        <div class="form-group">
                            <label>Kategori</label>
                            <select class="form-control" name="id_kategori">
                                <?php
                                foreach ($kategori as $k) {
                                ?>
                                    <option value="<?= $k->id_kategori ?>"><?= $k->nama_kategori ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Satuan</label>
                            <select class="form-control" name="id_satuan">
                                <?php
                                foreach ($satuan as $s) {
                                ?>
                                    <option value="<?= $s->id_satuan ?>"><?= $s->nama_satuan ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-success" type="submit" style="float: right;">
                            Simpan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Akun-->