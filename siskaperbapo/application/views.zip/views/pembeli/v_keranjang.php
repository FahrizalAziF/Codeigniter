<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mb-4"> <i class="fa fa-shopping-cart" aria-hidden="true"></i>Keranjang Belanja</h2>
            <p class="mb-5"> <i class="fa fa-shopping-cart" aria-hidden="true"></i>Daftar Pembelian Anda</p>
            <?php echo $this->session->flashdata('message'); ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Produk</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Harga/Satuan</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col" style="text-align: center;">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    $qty = 0;
                    foreach ($keranjang as $p) {
                        $this->db->where('id_satuan', $p->id_satuan);
                        $s = $this->db->get('tbl_satuan')->row();
                        $qty = $qty + $p->sub_total;
                    ?>
                        <tr>
                            <th scope="row"><?= $i++ ?></th>
                            <td><?= $p->nama_produk ?></td>
                            <td><img src="<?= base_url() ?>upload/<?= $p->foto_produk ?>" width="50px" height="50px"></td>
                            <td><?= $p->harga_produk ?>/<?= $s->nama_satuan ?></td>
                            <td>
                                <form method="POST" action="<?= base_url() ?>Keranjang/updateProduk">
                                    <input name="id_keranjang" hidden value="<?= $p->id_keranjang ?>">
                                    <input name="harga_produk" hidden value="<?= $p->harga_produk ?>">
                                    <input class="form-control mb-1" style="width: 50px;" name="jumlah" value="<?= $p->jumlah ?>">
                                    <button class="btn btn-warning  btn-sm" type="submit">Ubah</button>
                                </form>
                            </td>
                            <td><?= $p->sub_total ?></td>
                            <td style=" text-align: center;">
                                <a class="btn btn-danger mb-1" href="<?= base_url('Keranjang/deleteProduk/' . $p->id_keranjang) ?>"><i class="fas fa-trash"></i> </a>
                            </td>
                        </tr>

                    <?php } ?>
                    <tr>
                        <td colspan="6"><b>Total Harga </b></td>
                        <td><b>Rp.<?= $qty ?></b></td>
                    </tr>
                    <tr>
                        <td colspan="7">
                            <form method="post" action="<?= base_url('Keranjang/addTransaksi') ?> ">
                                <input hidden name="total_bayar" value="<?= $qty ?>">
                                <button type="submit" class="btn btn-success">Check Out</button>
                            </form>

                        </td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <div class="row">

            </div>
        </div>
    </div>
</div>